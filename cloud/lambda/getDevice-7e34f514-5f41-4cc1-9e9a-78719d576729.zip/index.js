const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient();

exports.handler = (event, context, callback) => {
    //const requestBody = JSON.parse(event.queryString); 
    //console.log('Body: ' + requestBody);
    console.log("test..",event.query, context.query);
    let id = "jmdt1";
    readDevice(id).then((data) => {
        console.log(data);
        let dev = data.Items[0];
        callback(null, {
            statusCode: 201,
            body: JSON.stringify({
                deviceID: dev.dev_id,
                temperature: dev.temperature,
                humidity: dev.humidity,
                vBat : dev.vBat
            }),
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
            isBase64Encoded : false
        });
    }).catch((err) => {
        console.error(err);

        // If there is an error during processing, catch it and return
        // from the Lambda function successfully. Specify a 500 HTTP status
        // code and provide an error message in the body. This will provide a
        // more meaningful error response to the end client.
        errorResponse(err.message, context.awsRequestId, callback)
    });
};

function readDevice(id) {
    return ddb.query({
        TableName: 'jdmt-device-data',
        KeyConditionExpression: "dev_id = :id",
        ExpressionAttributeValues: {
            ":id": id
        }
    }).promise();
}

function errorResponse(errorMessage, awsRequestId, callback) {
  callback(null, {
    statusCode: 500,
    body: JSON.stringify({
      Error: errorMessage,
      Reference: awsRequestId,
    }),
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
  });
}

